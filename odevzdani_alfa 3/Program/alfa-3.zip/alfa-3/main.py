from Code.Controler.Meny import Meny

meny=Meny()
meny.start_program()






